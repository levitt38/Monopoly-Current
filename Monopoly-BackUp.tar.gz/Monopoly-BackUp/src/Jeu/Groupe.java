package Jeu;
import Data.CouleurPropriete;


public class Groupe {
	private CouleurPropriete couleur;
}